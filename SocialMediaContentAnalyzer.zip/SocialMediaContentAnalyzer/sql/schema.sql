-- SQL schema for the project
CREATE TABLE users (id INT PRIMARY KEY, name VARCHAR(255));