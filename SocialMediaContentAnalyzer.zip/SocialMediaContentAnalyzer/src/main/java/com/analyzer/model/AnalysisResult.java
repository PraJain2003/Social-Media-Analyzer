package com.analyzer.model;

public class AnalysisResult {
    // Model for analysis results
}