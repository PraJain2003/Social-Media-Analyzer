package com.analyzer.utils;

public class TextExtractor {
    // Text extraction logic
}