package com.analyzer.controller;

public class FileUploadServlet {
    // File upload logic here
}